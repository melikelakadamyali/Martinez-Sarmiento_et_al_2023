function data_load = load_single_tiff_image()
[file_name,path] = uigetfile({'*.tif';'*.tiff'},'Select TIFF File(s)','MultiSelect','on');
if isequal(file_name,0)
    data_load=[];
else
    file_name=cellstr(file_name);
    for i = 1:length(file_name)
        try
            data_load{i} = load_tiff(path,file_name{i});
        catch
            msgbox(strcat('data should be a stack tiff image'));
            data_load{i}=[];
        end
    end
    data_load = data_load(~cellfun('isempty',data_load));
end
end

function data_load = load_tiff(path,file_name)
image = double(imread(fullfile(path,file_name)));
data_load.image{1} = image;
data_load.name = file_name(1:end-4);
data_load.type = 'image';
data_load.info = 'NaN';
end