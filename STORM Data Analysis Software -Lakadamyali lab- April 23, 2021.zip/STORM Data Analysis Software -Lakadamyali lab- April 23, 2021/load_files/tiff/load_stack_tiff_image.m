function data_load = load_stack_tiff_image()
[file_name,path] = uigetfile({'*.tif';'*.tiff'},'Select TIFF File(s)','MultiSelect','on');
if isequal(file_name,0)
    data_load=[];
else
    file_name=cellstr(file_name);
    for i = 1:length(file_name)
        try
            data_load{i} = load_tiff(path,file_name{i});
        catch
            msgbox(strcat('data should be a stack tiff image'));
            data_load{i}=[];
        end
    end
    data_load = data_load(~cellfun('isempty',data_load));
end
end

function data_load = load_tiff(path,file_name)
info = imfinfo(fullfile(path,file_name));
N=numel(info);
f=waitbar(0,'Please wait...');
for i =1:N
    image{i} = double(imread(fullfile(path,file_name),i));
    waitbar(i/N,f,'Please wait...');
end
close(f)
data_load.image = image;
data_load.name = file_name(1:end-4);
data_load.type = 'image';
data_load.info = 'NaN';
end