function [tracks_colocalized,tracks_not_colocalized] = spt_layover_module_colocalization(tracks,image,pixel_size,percentage_value)
tracks_norm = cellfun(@(x) x(:,2:3)/pixel_size,tracks,'UniformOutput',false);
tracks_norm_round = cellfun(@(x) round(x),tracks_norm,'UniformOutput',false);
for i = 1:length(tracks_norm_round)
    I = tracks_norm_round{i}(:,1)==0;
    tracks_norm_round{i}(I,1) = 1;
    clear I
    I = tracks_norm_round{i}(:,2)==0;
    tracks_norm_round{i}(I,2) = 1;
    clear I
end

counts = zeros(length(tracks_norm_round),2);
for i = 1:length(tracks_norm_round)    
    for k = 1:size(tracks_norm_round{i},1)
        if image(tracks_norm_round{i}(k,2),tracks_norm_round{i}(k,1))==255
            counts(i,1) = counts(i,1)+1;            
        else
            counts(i,2) = counts(i,2)+1;    
        end        
    end
end

localizaed_tracks = false(size(counts,1),1);
for m = 1:size(counts,1)
    if counts(m,1)>=(sum(counts(m,:))*percentage_value/100)
        localizaed_tracks(m,1) = true;
    end
end

tracks_colocalized = tracks(localizaed_tracks);
tracks_not_colocalized = tracks(~localizaed_tracks);
end