function spt_layover_module()
figure();
set(gcf,'name','Single Particle Tracks Tiff Image Layover','NumberTitle','off','color','w','units','normalized','position',[0.3 0.2 0.4 0.6],'menubar','none','toolbar','none','WindowButtonMotionFcn',@mouse_move,'WindowButtonDownFcn',@mouse_down,'windowkeypressfcn',@key_press,'windowscrollWheelFcn',@mouse_scroll)
global data listbox
uicontrol('style','pushbutton','units','normalized','position',[0,0.95,0.13,0.05],'string','Select Tiff','ForegroundColor','b','Callback',{@select_tiff_callback},'FontSize',12);
uicontrol('style','pushbutton','units','normalized','position',[0,0.9,0.13,0.05],'string','Setect Tracks','ForegroundColor','b','Callback',{@select_tracks_callback},'FontSize',12);
uicontrol('style','pushbutton','units','normalized','position',[0,0.85,0.13,0.05],'string','Colocalization','ForegroundColor','b','Callback',{@colocalization_callback},'FontSize',12);

uicontrol('style','pushbutton','units','normalized','position',[0,0.65,0.13,0.05],'string','Rec Select','ForegroundColor','b','Callback',{@rectangle_select},'FontSize',12);
uicontrol('style','pushbutton','units','normalized','position',[0,0.60,0.13,0.05],'string','Rec Deselect','ForegroundColor','b','Callback',{@rectangle_deselect},'FontSize',12);



uicontrol('style','text','units','normalized','position',[0,0,0.2,0.05],'string','Image Pixel Size','ForegroundColor','b','FontSize',12);
pixel_size_eidt = uicontrol('style','edit','units','normalized','position',[0.2,0,0.2,0.05],'string','0.117','ForegroundColor','b','Callback',{@pixel_size_edit_callback},'FontSize',12);
pixel_size = str2double(pixel_size_eidt.String);

current_point = [];
tracks = [];
tracks_selected = [];
image = [];
name = [];
axis off

file_menu = uimenu('Text','File');
uimenu(file_menu,'Text','Send Data to Workspace','Callback',@send_selected_data);

    function send_selected_data(~,~,~)
        data_to_send.tracks = tracks;
        data_to_send.name = name;
        data_to_send.type = 'spt';
        send_selected_data_to_workspace(data_to_send)
    end

    function send_selected_data_to_workspace(data_to_send)
        if isempty(data)==1
            data=data_to_send;
        else
            data= horzcat(data,data_to_send);
        end
        if isempty(data)==1
            listbox.String = 'NaN';
        else
            for i=1:length(data)
                names{i} = data{i}.name;
            end
            listbox.String = names;
        end
    end

edit_menu = uimenu('Text','Edit');
% uimenu(edit_menu,'Text','Rectangle Select','Callback',@rectangle_select);
% uimenu(edit_menu,'Text','Rectangle Deselect','Callback',@rectangle_deselect);
uimenu(edit_menu,'Text','Delete Selected Tracks (Red Color)','Callback',@delete_selected_tracks);

    function mouse_scroll (~,event)
        scroll_value = event.VerticalScrollCount;
        if scroll_value == -1
            zoom(1.1)
        elseif scroll_value == 1
            zoom(0.9)
        end
    end

    function key_press(~,event)
        key_pressed = event.Key;  
        xx = xlim;
        yy = ylim;
        if isequal(key_pressed,'rightarrow')            
            xlim(xx+diff(xx)/5)
        elseif isequal(key_pressed,'leftarrow')            
            xlim(xx-diff(xx)/5)
        elseif isequal(key_pressed,'uparrow')            
            ylim(yy+diff(yy)/5)
        elseif isequal(key_pressed,'downarrow')            
            ylim(yy-diff(yy)/5)
        end
    end

    function pixel_size_edit_callback(~,~,~)
        pixel_size = str2double(pixel_size_eidt.String);
        plot_all()
    end

    function select_tracks_callback(~,~,~)
        listbox_value = listbox.Value;
        if isempty(data)~=1
            try
                tracks = [];
                tracks_selected = [];
                tracks = data(listbox_value);
                name = tracks{1}.name;
                tracks = tracks{1}.tracks;                
                plot_all()
            end
        end
    end

    function select_tiff_callback(~,~,~)
        listbox_value = listbox.Value;
        if isempty(data)~=1
            try
                image = data(listbox_value);
                image = image{1}.image{1};
                x_data = linspace(0,size(image,2)*pixel_size,size(image,2));
                y_data = linspace(0,size(image,1)*pixel_size,size(image,1));                
                xlim([min(x_data) max(x_data)])
                ylim([min(y_data) max(y_data)])
                plot_all()
            end
        end
    end

    function plot_all()
        pixel_size = str2double(pixel_size_eidt.String);              
        xx = xlim;
        yy = ylim;
        ax = gca; cla(ax); 
        hold on
        if isempty(image)~=1
            plot_image(image)
        end
        if isempty(tracks)~=1
            plot_tracks(tracks)
        end
        if isempty(tracks_selected)~=1
            plot_selected_tracks(tracks_selected)
        end
        set(gca,'xlim',xx,'ylim',yy);
        title({['Number of Blue Tracks = ',num2str(length(tracks))],['Number of Red Tracks = ',num2str(length(tracks_selected))]},'interpreter','latex','fontsize',14)
    end

    function plot_tracks(data)
        for i = 1:length(data)
            line(data{i}(:,2),data{i}(:,3),'color','b')
        end
        %axis equal
        axis off        
    end

    function plot_selected_tracks(data)
        for i = 1:length(data)
            line(data{i}(:,2),data{i}(:,3),'color','r')
        end
        %axis equal
        axis off        
    end

    function plot_image(data)
        x_data = linspace(0,size(data,2)*pixel_size,size(data,2));
        y_data = linspace(0,size(data,1)*pixel_size,size(data,1));
        imagesc('xdata',x_data,'ydata',y_data','cdata',data,'alphadata',1);
        colormap(gray)
        %axis equal
        axis off   
    end

    function mouse_move(~,~)
        current_point=get(gca,'CurrentPoint');
    end

    function mouse_down(~,~)        
        if isequal(get(gcf,'SelectionType'),'normal')
            x = current_point(1,1);
            y = current_point(1,2);
            try
                to_find = tracks(:,1);
                index = cell(length(to_find),1);
                for k = 1:length(to_find)
                    index{k} = k*ones(size(tracks{k,1},1),1);
                end
                to_find = vertcat(to_find{:});
                index = vertcat(index{:});
                
                idx = knnsearch(to_find(:,2:3),[x,y],'K',2);
                selected = index(idx(2));
                
                tracks_selected = [tracks_selected;tracks(selected,:)];
                tracks_selected = tracks_selected(~cellfun('isempty',tracks_selected));
                
                tracks(selected,:) = [];
                tracks = tracks(~cellfun('isempty',tracks));
                
                plot_all()
            end
            
        elseif isequal(get(gcf,'SelectionType'),'alt')
            x = current_point(1,1);
            y = current_point(1,2);
            try
                to_find = tracks_selected(:,1);
                index = cell(length(to_find),1);
                for k = 1:length(to_find)
                    index{k} = k*ones(size(tracks_selected{k,1},1),1);
                end
                to_find = vertcat(to_find{:});
                index = vertcat(index{:});
                
                
                idx = knnsearch(to_find(:,2:3),[x,y],'K',2);
                selected = index(idx(2));
                
                tracks = [tracks;tracks_selected(selected,:)];
                tracks = tracks(~cellfun('isempty',tracks));
                
                tracks_selected(selected,:) = [];
                tracks_selected = tracks_selected(~cellfun('isempty',tracks_selected));
                
                plot_all()
            end
        end
    end

    function rectangle_select(~,~,~)
        coordinates = getrect();
        x1 = coordinates(1);
        x2 = x1+coordinates(3);
        y1 = coordinates(2);
        y2 = y1+coordinates(4);
        I1 = min(x1,x2);
        I2 = max(x1,x2);
        I3 = min(y1,y2);
        I4 = max(y1,y2);
        if I1==I2 || I3==I4
            return
        else
            try
                to_find = tracks(:,1);
                index = cell(length(to_find),1);
                for k = 1:length(to_find)
                    index{k} = k*ones(size(tracks{k,1},1),1);
                end
                to_find = vertcat(to_find{:});
                index = vertcat(index{:});
                
                
                x_find = find(to_find(:,2)>=I1 & to_find(:,2)<=I2);
                y_find = find(to_find(:,3)>=I3 & to_find(:,3)<=I4);
                I = intersect(x_find,y_find);
                selected = index(I);
                selected = unique(selected);
                
                tracks_selected = [tracks_selected;tracks(selected,:)];
                tracks_selected = tracks_selected(~cellfun('isempty',tracks_selected));
                
                tracks(selected,:) = [];
                tracks = tracks(~cellfun('isempty',tracks));
                
                plot_all()
            end
        end
    end

    function rectangle_deselect(~,~,~)
        coordinates = getrect();
        x1 = coordinates(1);
        x2 = x1+coordinates(3);
        y1 = coordinates(2);
        y2 = y1+coordinates(4);
        I1 = min(x1,x2);
        I2 = max(x1,x2);
        I3 = min(y1,y2);
        I4 = max(y1,y2);
        if I1==I2 || I3==I4
            data_crop = [];
        else
            try
                to_find = tracks_selected(:,1);
                index = cell(length(to_find),1);
                for k = 1:length(to_find)
                    index{k} = k*ones(size(tracks_selected{k,1},1),1);
                end
                to_find = vertcat(to_find{:});
                index = vertcat(index{:});
                
                
                x_find = find(to_find(:,2)>=I1 & to_find(:,2)<=I2);
                y_find = find(to_find(:,3)>=I3 & to_find(:,3)<=I4);
                I = intersect(x_find,y_find);
                selected = index(I);
                selected = unique(selected);
                
                tracks = [tracks;tracks_selected(selected,:)];
                tracks = tracks(~cellfun('isempty',tracks));
                
                tracks_selected(selected,:) = [];
                tracks_selected = tracks_selected(~cellfun('isempty',tracks_selected));
                
                plot_all()
            end
        end
    end

    function delete_selected_tracks(~,~,~)
        tracks_selected = [];
        plot_all()
    end

    function colocalization_callback(~,~,~)
        input_values = inputdlg({'Colocalization Percentage:'},'',1,{'40'});
        if isempty(input_values)==1
            return
        else
            percentage_value = str2double(input_values{1});
            [tracks,tracks_selected] = spt_layover_module_colocalization(tracks,image,pixel_size,percentage_value);
            plot_all()
        end
    end
end