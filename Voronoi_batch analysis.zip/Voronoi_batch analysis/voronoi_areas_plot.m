function voronoi_areas_plot(data)
percentile_range = [0 99];
f = waitbar(0,'Calculating PDF and CDF..');
for i = 1:length(data)
    waitbar(i/length(data),f,['Calculating PDF and CDF..',num2str(i),'/',num2str(length(data))]);
    [x_pdf{i},y_pdf{i},x_cdf{i},y_cdf{i}] = calculate_pdf_cdf(data{i}.vor.voronoi_areas,percentile_range);
    [x_pdf_norm{i},y_pdf_norm{i},x_cdf_norm{i},y_cdf_norm{i}] = calculate_pdf_cdf_norm(data{i}.vor.voronoi_areas,percentile_range);
    names{i} = data{i}.name;
end
close(f)

figure()
set(gcf,'name','Voronoi Segmentation','NumberTitle','off','color','w','units','normalized','position',[0.15 0.1 0.5 0.8],'menubar','none','toolbar','figure')

voronoi_data_plot_inside(x_pdf,y_pdf,x_cdf,y_cdf,x_pdf_norm,y_pdf_norm,x_cdf_norm,y_cdf_norm,names,percentile_range)

data_menu = uimenu('Text','Data');
uimenu(data_menu,'Text','Voronoi Area Data','ForegroundColor','b','CallBack',@voronoi_data);
uimenu(data_menu,'Text','CDF Data','ForegroundColor','b','CallBack',@cdf_data);
uimenu(data_menu,'Text','PDF Data','ForegroundColor','b','CallBack',@pdf_data);
uimenu(data_menu,'Text','CDF Norm Data','ForegroundColor','b','CallBack',@cdf_norm_data);
uimenu(data_menu,'Text','PDF Norm Data','ForegroundColor','b','CallBack',@pdf_norm_data);
uimenu(data_menu,'Text','Voronoi Area Percentiles','ForegroundColor','b','CallBack',@voronoi_area_percentiles);
uimenu(data_menu,'Text','Voronoi Area Percentiles Table','ForegroundColor','b','CallBack',@voronoi_area_percentiles_table);
uimenu(data_menu,'Text','Normalized Voronoi Area Percentiles Table','ForegroundColor','b','CallBack',@normalized_voronoi_area_percentiles_table);


    function voronoi_data_plot_inside(x_pdf,y_pdf,x_cdf,y_cdf,x_pdf_norm,y_pdf_norm,x_cdf_norm,y_cdf_norm,names,percentile_range)        
        subplot(2,2,1)
        hold on
        for k = 1:length(x_pdf)
            plot(x_pdf{k},y_pdf{k})            
        end
        box on
        grid on
        set(gca,'TickDir','out','TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        if length(names)<5
            legend(regexprep(names,'_',' '))
        end
        xlabel(['Voronoi Areas, [',num2str(percentile_range), '] Percentile'],'interpreter','latex','fontsize',16)
        ylabel('PDF','interpreter','latex','fontsize',16)
        pbaspect([1,1,1])
        
        subplot(2,2,2)
        hold on
        for k = 1:length(x_cdf)
            plot(x_cdf{k},y_cdf{k}) 
        end
        box on 
        grid on
        set(gca,'TickDir','out','TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        if length(names)<5
            legend(regexprep(names,'_',' '))
        end
        xlabel(['Voronoi Areas, [',num2str(percentile_range), '] Percentile'],'interpreter','latex','fontsize',16)
        ylabel('CDF','interpreter','latex','fontsize',16)
        pbaspect([1,1,1]) 
        
        subplot(2,2,4)
        hold on
        for k = 1:length(x_cdf)
            plot(x_cdf_norm{k},y_cdf_norm{k}) 
        end
        box on 
        grid on
        set(gca,'TickDir','out','TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        if length(names)<5
            legend(regexprep(names,'_',' '))
        end
        xlabel(['Normalized Voronoi Areas, [',num2str(percentile_range), '] Percentile'],'interpreter','latex','fontsize',16)
        ylabel('CDF','interpreter','latex','fontsize',16)
        pbaspect([1,1,1]) 
        
        subplot(2,2,3)
        hold on
        for k = 1:length(x_cdf)
            plot(x_pdf_norm{k},y_pdf_norm{k}) 
        end
        box on 
        grid on
        set(gca,'TickDir','out','TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        if length(names)<5
            legend(regexprep(names,'_',' '))
        end
        xlabel(['Normalized Voronoi Areas, [',num2str(percentile_range), '] Percentile'],'interpreter','latex','fontsize',16)
        ylabel('PDF','interpreter','latex','fontsize',16)
        pbaspect([1,1,1])
    end
   
    function voronoi_data(~,~,~)
        for k = 1:length(data)
            data_table{k} = voronoi_data_table(data{k});
        end
        plot_data_table(data_table,{'Voronoi Areas','Normalized Voronoi Areas'})
    end

    function cdf_data(~,~,~)
        for k = 1:length(data)
            data_table{k}.data(:,1) = x_cdf{k};
            data_table{k}.data(:,2) = y_cdf{k};
            data_table{k}.name = data{k}.name;
        end
        plot_data_table(data_table,{'x_CDF Voronoi Areas','y_CDF Voronoi Areas'})
    end

    function pdf_data(~,~,~)
        for k = 1:length(data)
            data_table{k}.data(:,1) = x_pdf{k};
            data_table{k}.data(:,2) = y_pdf{k};            
            data_table{k}.name = data{k}.name;
        end
        plot_data_table(data_table,{'x_PDF Voronoi Areas','y_PDF Voronoi Areas'})
    end

    function cdf_norm_data(~,~,~)
        for k = 1:length(data)
            data_table{k}.data(:,1) = x_cdf_norm{k};
            data_table{k}.data(:,2) = y_cdf_norm{k};
            data_table{k}.name = data{k}.name;
        end
        plot_data_table(data_table,{'x_CDF Normalized Voronoi Areas','y_CDF Normalized Voronoi Areas'})
    end

    function pdf_norm_data(~,~,~)
        for k = 1:length(data)
            data_table{k}.data(:,1) = x_pdf_norm{k};
            data_table{k}.data(:,2) = y_pdf_norm{k};            
            data_table{k}.name = data{k}.name;
        end
        plot_data_table(data_table,{'x_PDF Normalized Voronoi Areas','y_PDF Normalized Voronoi Areas'})
    end

    function voronoi_area_percentiles(~,~,~)
        voronoi_area_percentiles_inside(data)
    end

    function normalized_voronoi_area_percentiles_table(~,~,~)
        normalized_voronoi_area_percentiles_table_inside(data)
    end

    function voronoi_area_percentiles_table(~,~,~)
        voronoi_area_percentiles_table_inside(data)
    end
end

function data_table = voronoi_data_table(data)
va = data.vor.voronoi_areas;
va_mean = va;
va_mean(isnan(va_mean)) = [];
va_mean = mean(va_mean);
va(:,2) = va/va_mean;
data_table.data = va;
data_table.name = data.name;
end

function plot_data_table(data,column_names)
figure()
set(gcf,'name','voronoi_areas_data','NumberTitle','off','color','w','units','normalized','position',[0.3 0.2 0.4 0.6],'menubar','none','toolbar','figure')

if length(data)>1
    slider_step=[1/(length(data)-1),1];
    uicontrol('style','slider','units','normalized','position',[0,0,0.05,0.9],'value',1,'min',1,'max',length(data),'sliderstep',slider_step,'Callback',{@sld_callback});
end
slider_value=1;
slider_plot_inside(data{slider_value})

uimenu('Text','Save Data (.txt file)','ForegroundColor','b','CallBack',@save_data);

    function save_data(~,~,~)
        [file,path] = uiputfile('*.txt');
        if path~=0      
            f = waitbar(0,'Writing Files');
            for i = 1:length(data)
                files_name = [file,'_',data{i}.name];
                save_to = fullfile(path,files_name);   
                dlmwrite(save_to,data{i}.data)
                clear save_to file_name
                waitbar(i/length(data),f,'writing Files');
            end
            close(f)
        end
    end
    function sld_callback(hobj,~,~)
        slider_value = round(get(hobj,'Value'));        
        slider_plot_inside(data{slider_value})
    end

    function slider_plot_inside(data)
        axis off
        title(regexprep(data.name,'_',' '),'interpreter','latex','fontsize',18)
        uitable('Data',data.data,'units','normalized','position',[0.05 0 0.95 0.9],'ColumnWidth',{150},'FontSize',12,'ColumnName',column_names);
    end
end

function voronoi_area_percentiles_inside(data)
input = inputdlg({'Number of Percentiles'},'',1,{'2'});
if isempty(input)~=1
    no_of_percentile_ranges = str2double(input{1});    
    for i=1:no_of_percentile_ranges
        prompt{i} = ['cell ',num2str(i),' percentile range'];
        default_input{i} = '10 90';
    end
    answer = inputdlg(prompt,'Input space separated numbers',1,default_input);
    
    if isempty(answer)~=1
        f = waitbar(0,'Calculating CDF');
        for i=1:length(data)
            waitbar(i/length(data),f,['Calculating CDF...',num2str(i),'/',num2str(length(data))]);             
            data_cdf_pdf{i} = find_cdf_pdf(data{i}.vor.voronoi_areas,answer);
            names{i} = data{i}.name;
        end
        close(f)        
        plot_data_cdf_pdf(data_cdf_pdf,names)        
    end
end

    function data_cdf_pdf = find_cdf_pdf(areas,percentile)
        for m = 1:length(percentile)
            range = str2num(percentile{m});            
            I1 = prctile(areas,range(1));
            I2 = prctile(areas,range(2));
            wanted = areas(areas<I2 & areas>I1);
            x_hist = linspace(min(wanted),max(wanted),5000);
            y_pdf = histcounts(wanted,x_hist,'normalization','probability');
            y_pdf = y_pdf/sum(y_pdf);
            y_cdf = histcounts(wanted,x_hist,'normalization','cdf');
            x_pdf = x_hist(1:end-1);
            x_cdf = x_hist(1:end-1);
            data_cdf_pdf{1,m}(:,1) = x_cdf;
            data_cdf_pdf{1,m}(:,2) = y_cdf;
            data_cdf_pdf{2,m} = [I1,I2];
            data_cdf_pdf{3,m} = range;
            data_cdf_pdf{4,m}(:,1) = x_pdf;
            data_cdf_pdf{4,m}(:,2) = y_pdf;            
            clear range I1 I2 wanted x_hist x_pdf y_pdf x_cdf y_cdf
         end 
    end
end

function voronoi_area_percentiles_table_inside(data)
input = inputdlg({'Number of Percentiles'},'',1,{'2'});
if isempty(input)~=1
    no_of_percentile_ranges = str2double(input{1});    
    for i=1:no_of_percentile_ranges
        prompt{i} = [' percentile value ',num2str(i)];
        default_input{i} = '10';
    end
    answer = inputdlg(prompt,'Input space separated numbers',1,default_input);
    
    if isempty(answer)~=1
        f = waitbar(0,'Calculating Percentiles');
        for i=1:length(data)
            waitbar(i/length(data),f,['Calculating Percentiles...',num2str(i),'/',num2str(length(data))]);             
            voronoi_areas_percentiles{i} = find_voronoi_areas_percentiles(data{i}.vor.voronoi_areas,answer);
            names{i} = data{i}.name;
        end
        voronoi_areas_percentiles = vertcat(voronoi_areas_percentiles{:});
        close(f)             
    end
    table_data_plot(voronoi_areas_percentiles,names,answer,'Voronoi Areas Percentiles')
end

    function percentile_value = find_voronoi_areas_percentiles(areas,percentile)              
        for m = 1:length(percentile)            
            percentile_value(1,m) = prctile(areas,str2double(percentile{m}));            
        end
    end
end

function normalized_voronoi_area_percentiles_table_inside(data)
input = inputdlg({'Number of Percentiles'},'',1,{'2'});
if isempty(input)~=1
    no_of_percentile_ranges = str2double(input{1});    
    for i=1:no_of_percentile_ranges
        prompt{i} = [' percentile value ',num2str(i)];
        default_input{i} = '10';
    end
    answer = inputdlg(prompt,'Input space separated numbers',1,default_input);
    
    if isempty(answer)~=1
        f = waitbar(0,'Calculating Percentiles');
        for i=1:length(data)
            waitbar(i/length(data),f,['Calculating Percentiles...',num2str(i),'/',num2str(length(data))]);             
            voronoi_areas_percentiles{i} = find_voronoi_areas_percentiles(data{i}.vor.voronoi_areas,answer);
            names{i} = data{i}.name;
        end
        voronoi_areas_percentiles = vertcat(voronoi_areas_percentiles{:});
        close(f)             
    end
    table_data_plot(voronoi_areas_percentiles,names,answer,'Normalized Voronoi Areas Percentiles')
end

    function percentile_value = find_voronoi_areas_percentiles(areas,percentile)
        temp = areas;
        temp(isnan(temp)) = [];
        areas = areas/mean(temp);        
        for m = 1:length(percentile)            
            percentile_value(1,m) = prctile(areas,str2double(percentile{m}));            
        end
    end
end

function plot_data_cdf_pdf(data,name)
figure()
set(gcf,'name','percentiles','NumberTitle','off','color','w','units','normalized','position',[0.15 0.2 0.7 0.5],'menubar','none','toolbar','figure')

if length(data)>1
    slider_step=[1/(length(data)-1),1];
    uicontrol('style','slider','units','normalized','position',[0,0,0.03,1],'value',1,'min',1,'max',length(data),'sliderstep',slider_step,'Callback',{@sld_callback});
end
slider_value=1;
slider_plot_inside(data{slider_value},name{slider_value})


    function sld_callback(hobj,~,~)
        slider_value = round(get(hobj,'Value'));        
        slider_plot_inside(data{slider_value},name{slider_value})
    end

    function slider_plot_inside(data,name)        
        subplot(1,2,2)
        ax = gca; cla(ax);
        hold on
        for i = 1:size(data,2)
            plot(data{1,i}(:,1),data{1,i}(:,2))
            percentiles{i} = [num2str(data{3,i}(1)),' percentile:',num2str(data{2,i}(1)),'/',num2str(data{3,i}(2)),' percentile:',num2str(data{2,i}(2))];
        end
        title(regexprep(name,'_',' '),'interpreter','latex','fontsize',16)
        legend(percentiles)
        set(gca,'TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        box on
        xlabel('Voronoi Areas','interpreter','latex','fontsize',16)
        ylabel('CDF','interpreter','latex','fontsize',16)
        
        subplot(1,2,1)
        ax = gca; cla(ax);
        hold on
        for i = 1:size(data,2)
            plot(data{4,i}(:,1),data{4,i}(:,2))           
        end        
        set(gca,'TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        box on
        xlabel('Voronoi Areas','interpreter','latex','fontsize',16)
        ylabel('PDF','interpreter','latex','fontsize',16)
    end
end

function [x_pdf,y_pdf,x_cdf,y_cdf] = calculate_pdf_cdf(data,percentile)
I1 = prctile(data,percentile(1));
I2 = prctile(data,percentile(2));
wanted = data(data<I2 & data>I1);
x_hist = linspace(min(wanted),max(wanted),5000);
y_pdf = histcounts(wanted,x_hist,'normalization','probability');
y_cdf = histcounts(wanted,x_hist,'normalization','cdf');
x_pdf = x_hist(1:end-1);
x_cdf = x_hist(1:end-1);
end

function [x_pdf,y_pdf,x_cdf,y_cdf] = calculate_pdf_cdf_norm(data,percentile)
temp = data;
temp(isnan(temp)) = [];
data = data/mean(temp);
I1 = prctile(data,percentile(1));
I2 = prctile(data,percentile(2));
wanted = data(data<I2 & data>I1);
x_hist = linspace(min(wanted),max(wanted),1000);
y_pdf = histcounts(wanted,x_hist,'normalization','probability');
y_cdf = histcounts(wanted,x_hist,'normalization','cdf');
x_pdf = x_hist(1:end-1);
x_cdf = x_hist(1:end-1);
end

function table_data_plot(data,row_names,column_names,title)
figure('name',title,'NumberTitle','off','units','normalized','position',[0 0.1 1 0.4],'ToolBar','none','MenuBar', 'none');
column_width = {200};
uitable('Data',data,'units','normalized','position',[0 0 1 1],'FontSize',12,'RowName',row_names,'ColumnName',column_names,'columnwidth',column_width);

uimenu('Text','Send Data to Excel Sheet','ForegroundColor','b','CallBack',@save_data);
    function save_data(~,~,~)
        [file,path] = uiputfile('*.xlsx');
        if path~=0
            save_to = fullfile(path,file);            
            data_table = array2table(data);
            data_table.Properties.VariableNames = column_names;
            data_table.Properties.RowNames = row_names;
            writetable(data_table,save_to,'WriteRowNames',true);                 
        end
    end
end