function vor = calculate_voronoi_structure_modified(data)
vor.vor = loc_list_construct_voronoi_structure(data.x_data,data.y_data,[1 length(data)]);  
vor.name = data.name;
end

function vor = loc_list_construct_voronoi_structure(x,y,counter)
f = waitbar(0,['Constructing Delauny Tirangle...',num2str(counter(1)),'/',num2str(counter(2))]);
dt = delaunayTriangulation(x,y);

waitbar(0.2,f,['Finding Vertices and Connections...',num2str(counter(1)),'/',num2str(counter(2))]);
[vertices,connections] = voronoiDiagram(dt);

waitbar(0.4,f,['Finding Voronoi Cells...',num2str(counter(1)),'/',num2str(counter(2))]);
voronoi_cells = cellfun(@(x) vertices(x,:),connections,'UniformOutput',false);

waitbar(0.6,f,['Calculating Voronoi Areas...',num2str(counter(1)),'/',num2str(counter(2))]);
voronoi_areas = cellfun(@(x) abs(sum( (x([2:end 1],1) - x(:,1)).*(x([2:end 2],2) + x(:,2)))*0.5),voronoi_cells,'UniformOutput',false);
idx = cell2mat(cellfun(@(x) isnan(x) | x == Inf,voronoi_areas,'UniformOutput',false));
cell_inf = cell(1);
cell_inf{1,1} = NaN;
voronoi_areas(idx) = cell_inf;

waitbar(0.9,f,['Finding Voronoi Neighbors...',num2str(counter(1)),'/',num2str(counter(2))]);
vor.voronoi_areas = cell2mat(voronoi_areas);
close(f)
end