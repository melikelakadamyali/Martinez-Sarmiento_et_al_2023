function data_outlier_removed = combine_outlier_removed_data_not_clustered(data_filtered,data_not_clustered)
data_outlier_removed.x_data = [data_not_clustered.x_data ; data_filtered.x_data];
data_outlier_removed.y_data = [data_not_clustered.y_data ; data_filtered.y_data];
data_outlier_removed.area = 0.7+zeros(length(data_outlier_removed.x_data),1);
data_outlier_removed.name = [data_not_clustered.name(1:end-22),'_outlier_removed'];
data_outlier_removed.type = 'loc_list';
end