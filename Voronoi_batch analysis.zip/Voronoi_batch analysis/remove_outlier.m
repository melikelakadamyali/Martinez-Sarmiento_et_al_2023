function [data_filtered,data_removed,plot_results] = remove_outlier(data,no_of_bins,sigma_to)
[data_filtered,data_removed,plot_results] = remove_outlier_from_area(data,no_of_bins,sigma_to,[1 length(data)]);
end

function [data_filtered,data_removed,plot_results] = remove_outlier_from_area(data,no_of_bins,sigma_to,counter)
f = waitbar(0,['Removing Outlier...',num2str(counter(1)),'/',num2str(counter(2))]);

clusters = loc_list_extract_clusters_from_data(data);
if length(clusters)>1
    for i = 1:length(clusters)
        areas(i) = clusters{i}(1,3);
        no_of_locs(i) = size(clusters{i},1);
    end
    data_to_process(:,1) = no_of_locs;
    data_to_process(:,2) = areas;
    ratio = data_to_process(:,2)./data_to_process(:,1);
    [count,centers] = hist(ratio',no_of_bins);
    
    fit_to_hist = fitdist(ratio,'Normal');
    centers_interp = linspace(min(centers),max(centers),5000);
    fit_to_hist = pdf(fit_to_hist,centers_interp);
    
    [~,mu_I] = max(fit_to_hist);
    mu = centers_interp(mu_I);
    [~,sigma_I] = min(abs(fit_to_hist-(exp(1)^(-0.5))*max(fit_to_hist)));
    sigma = abs(mu-centers_interp(sigma_I));
    to_keep_data_idx = ratio<mu+sigma_to*sigma & ratio>mu-sigma_to*sigma;
    
    clusters_removed = clusters(~to_keep_data_idx);
    clusters = clusters(to_keep_data_idx);
    clusters = vertcat(clusters{:});
    data_filtered.x_data = clusters(:,1);
    data_filtered.y_data = clusters(:,2);
    data_filtered.area = clusters(:,3);
    data_filtered.type = 'loc_list';
    data_filtered.name = [data.name,'_filtered'];
    
    clusters_removed = vertcat(clusters_removed{:});
    data_removed.x_data = clusters_removed(:,1);
    data_removed.y_data = clusters_removed(:,2);
    data_removed.area = clusters_removed(:,3);
    data_removed.type = 'loc_list';
    data_removed.name = [data.name,'_removed_locs'];
    
    plot_results.to_keep_data = data_to_process(to_keep_data_idx,:);
    plot_results.removed_data = data_to_process(~to_keep_data_idx,:);
    plot_results.count = count;
    plot_results.centers = centers;
    plot_results.mu = mu;
    plot_results.sigma = sigma;
    plot_results.name = data.name;
    plot_results.centers_interp = centers_interp;
    plot_results.fit_to_hist = fit_to_hist;
    plot_results.sigma_to = sigma_to;
    waitbar(1,f,['Removing Outlier...',num2str(counter(1)),'/',num2str(counter(2))])
    close(f)
else
    plot_results = [];
    data_removed = [];
    data_filtered = [];
    close(f)
end
end

function clusters = loc_list_extract_clusters_from_data(data)
area = data.area;
count(1) = 1;
counter = 1;
for i = 2:length(area)
    if area(i)~=area(i-1)
        counter = counter+1;
        count(counter) = i;
    end
end
for i = 1:length(count)
    if i== length(count)
        clusters{i}(:,1) = data.x_data(count(i):length(area));
        clusters{i}(:,2) = data.y_data(count(i):length(area));
        clusters{i}(:,3) = data.area(count(i):length(area));
    else
        clusters{i}(:,1) = data.x_data(count(i):count(i+1)-1);
        clusters{i}(:,2) = data.y_data(count(i):count(i+1)-1);
        clusters{i}(:,3) = data.area(count(i):count(i+1)-1);
    end
end
end