function [data_clustered,data_not_clustered,area_threshold_table] = find_clusters(vor,area_threshold,min_number_of_localizations)
[data_clustered,data_not_clustered,area_threshold_table] = construct_clusters(vor,area_threshold,min_number_of_localizations,2,[1 length(vor)]);
end

function [data_clustered,data_not_clustered,area_threshold] = construct_clusters(data,area_threshold,min_number_of_localizations,type,waitbar_counter)
f = waitbar(0,['Please Wait...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
voronoi_areas = data.vor.voronoi_areas;
neighbors = data.vor.neighbors;
if type == 2    
    area_threshold = prctile(voronoi_areas,area_threshold);
end
keep_points = voronoi_areas <= area_threshold;
counter = 0;
number_of_points = size(voronoi_areas,1);
used_points = zeros(number_of_points,1);

waitbar(0.1,f,['Please Wait...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
for i = 1:number_of_points
    if keep_points(i) && ~used_points(i)
        % get the neighbors with area below the area threshold surrounding the seed-point
        seed_neighbors = neighbors{i}(keep_points(neighbors{i}));
        if ~isempty(seed_neighbors)
            size_one = 0;
            size_two = length(seed_neighbors);
            % find all connected neighbors above threshold
            while size_two ~= size_one
                size_one = length(seed_neighbors);
                idx_all = unique(cell2mat(neighbors(seed_neighbors)));
                if ~any(builtin('_ismemberhelper',idx_all,seed_neighbors))
                    seed_neighbors = sort([idx_all;seed_neighbors]);
                else
                    seed_neighbors = idx_all;
                end
                seed_neighbors = seed_neighbors(keep_points(seed_neighbors));
                size_two = length(seed_neighbors);
            end
        else
            seed_neighbors = i;
        end
        used_points(seed_neighbors) = 1;
        if length(seed_neighbors) >= min_number_of_localizations
            counter = counter+1;
            idx_clustered{counter} = seed_neighbors;
        end
    end    
end

waitbar(0.3,f,['Please Wait...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
idx_not_clustered = vertcat(idx_clustered{:});
idx_not_clustered = setxor(1:length(data.vor.neighbors),idx_not_clustered);
idx = 1:length(data.vor.neighbors);
idx(idx_not_clustered) = -1;
for i = 1:length(idx_clustered)
    idx(idx_clustered{i}) = i;
end

waitbar(0.5,f,['Please Wait...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
data_vor(:,1) = data.vor.points(:,1);
data_vor(:,2) = data.vor.points(:,2);
data_vor(:,3) = data.vor.voronoi_areas;

I = idx == -1;

waitbar(0.7,f,['Voronoi Segmentation Not-clustered Data...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
data_not_clustered.x_data = data_vor(I,1);
data_not_clustered.y_data = data_vor(I,2);
data_not_clustered.area = 0.7+zeros(length(data_not_clustered.x_data),1);
data_not_clustered.name = [data.name,'_voronoi_not_clustered'];
data_not_clustered.type = 'loc_list';

waitbar(0.9,f,['Voronoi Segmentation Clustered Data...',num2str(waitbar_counter(1)),'/',num2str(waitbar_counter(2))]);
idx(I) = [];
data_vor(I,:) = [];
%clusters = loc_list_find_clusters(data_vor,idx);
clusters = loc_list_find_clusters_inside(data_vor,idx);
clusters = vertcat(clusters{:});

data_clustered.x_data = clusters(:,1);
data_clustered.y_data = clusters(:,2);
data_clustered.area = clusters(:,3);
data_clustered.name = [data.name,'_clusters'];
data_clustered.type = 'loc_list';
close(f)
end

function clusters = loc_list_find_clusters_inside(data,idx)
idx_unique = unique(idx);
for i = 1:length(idx_unique)
    I = idx == idx_unique(i);   
    clusters{i}(:,1:2) = data(I,1:2);
    clusters{i}(:,3) = sum(data(I,3));
    clear I
end
end