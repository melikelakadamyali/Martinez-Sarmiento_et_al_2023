function plot_remove_outlier_results(data)
figure()
set(gcf,'name','Outlier Removal','NumberTitle','off','color','w','units','normalized','position',[0.05 0.2 0.9 0.5],'menubar','none','toolbar','figure');

if length(data)>1
    slider_step=[1/(length(data)-1),1];
    slider = uicontrol('style','slider','units','normalized','position',[0,0,0.02,1],'value',1,'min',1,'max',length(data),'sliderstep',slider_step,'Callback',{@sld_callback});
end
slider_value=1;
plot_inside(data{slider_value})

    function sld_callback(~,~,~)
        slider_value = round(slider.Value);
        if isempty(data{slider_value})~=1
            plot_inside(data{slider_value})
        end
    end

    function plot_inside(data)
        to_keep_data = data.to_keep_data;
        removed_data = data.removed_data;
        count = data.count;
        centers = data.centers;
        mu = data.mu;
        sigma = data.sigma;
        centers_interp = data.centers_interp;
        fit_to_hist = data.fit_to_hist;
        sigma_to = data.sigma_to;
        name = data.name;
        
        subplot(1,2,1)
        ax = gca; cla(ax);
        plot(centers,count/max(count),'color','k','linewidth',1.5)
        hold on
        plot(centers_interp,fit_to_hist/max(fit_to_hist),'color','b','linewidth',1.5)
        line([mu+sigma_to*sigma mu+sigma_to*sigma],[0 1],'color','r','linewidth',1.5)
        line([mu-sigma_to*sigma mu-sigma_to*sigma],[0 1],'color','r','linewidth',1.5)
        line([mu mu],[0 1],'color','k','linewidth',1.5)
        text(mu,0.9,['$\mu = $',num2str(mu)],'interpreter','latex','fontsize',16)
        text(mu+sigma_to*sigma,0.9,['$\mu + $',num2str(sigma_to),'$\sigma$'],'interpreter','latex','fontsize',16)
        text(mu-sigma_to*sigma,0.9,['$\mu - $',num2str(sigma_to),'$\sigma$'],'interpreter','latex','fontsize',16)
        set(gca,'TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        box on
        
        subplot(1,2,2)
        ax = gca; cla(ax);
        scatter(to_keep_data(:,1),to_keep_data(:,2),10,'b','filled')
        hold on
        scatter(removed_data(:,1),removed_data(:,2),10,'r','filled')
        title(regexprep(name,'_',' '),'interpreter','latex','fontsize',18)
        xlabel('Clusters No. of Locs','interpreter','latex','fontsize',18)
        ylabel('Clusters Area','interpreter','latex','fontsize',18)
        set(gca,'TickLength',[0.02 0.02],'FontName','TimesNewRoman','FontSize',12,'TickLabelInterpreter','latex')
        box on
    end
end