function data_load = load_microscopy_bin_file()
[file_name,path] = uigetfile('*.bin','Select .txt File(s)','MultiSelect','on');
if isequal(file_name,0)
    data_load=[];
else
    file_name=cellstr(file_name);    
    for i=1:length(file_name)
        f=waitbar(0,'Loading Bin File...');
        waitbar(0.1,f,['Loading Bin File....',num2str(i),'/',num2str(length(file_name))])  
        try            
            data_read = Insight3(fullfile(path,file_name{i})); 
            data_read = data_read.getXYcorr;            
            data_read = unique(data_read,'rows');            
        catch
            msgbox(strcat('data should be a bin file from high resolution microscopy data',file_name{i}));
            data_load{i}=[];            
            continue
        end 
        waitbar(0.5,f,['Loading Bin File....',num2str(i),'/',num2str(length(file_name))]) 
        data_load{i}.x_data = data_read(:,1);
        data_load{i}.y_data = data_read(:,2);
        data_load{i}.area = 0.7+zeros(length(data_read(:,1)),1);
        data_load{i}.name = file_name{1,i}(1:end-4);
        data_load{i}.type = 'loc_list';
        waitbar(1,f,['Loading Bin File....',num2str(i),'/',num2str(length(file_name))]) 
        close(f)
    end
    data_load = data_load(~cellfun('isempty',data_load));    
end
end