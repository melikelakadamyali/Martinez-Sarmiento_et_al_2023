clear;clc;close all;warning off

area_threshold = 70; % area threshold percentile for image-segmentation using voronoi-clustering
min_number_of_localizations = 100; % minimum number of localizations per cluster (voronoi-clustering)
no_of_bins = 100; % number of bins to build histogram of locs/area for clusteres to remove outliere clusters
sigma_to = 3; % 2*sigma from mean for outlier removal is kept

%------------------------------------------
%------------------------------------------
data = load_microscopy_bin_file();
if isempty(data)~=1
    for i = 1:length(data)
        disp([num2str(i),'/',num2str(length(data))])
        vor = calculate_voronoi_structure(data{i});
        [data_clustered,data_not_clustered,area_threshold_table(i,1)] = find_clusters(vor,area_threshold,min_number_of_localizations);
        [data_filtered,data_removed,plot_results{i,1}] = remove_outlier(data_clustered,no_of_bins,sigma_to);        
        data_outlier_removed{i} = combine_outlier_removed_data_not_clustered(data_filtered,data_not_clustered);
        clear data_clustered data_not_clustered data_filtered data_removed vor        
        data_outlier_removed_vor{i} = calculate_voronoi_structure_modified(data_outlier_removed{i});        
    end
end

plot_remove_outlier_results(plot_results)
voronoi_areas_plot(data_outlier_removed_vor)

[file,path] = uiputfile('*.mat');
if path~=0
    save(fullfile(path,file),'area_threshold_table','data_outlier_removed','data_outlier_removed_vor','plot_results')
end

[file,path] = uiputfile('*.bin');
i3 = Insight3();
for i=1:length(data_outlier_removed)
    X = data_outlier_removed{i}.x_data;
    Y = data_outlier_removed{i}.y_data;
    i3.setData( [X,Y] );
    i3.write(fullfile(path,[data_outlier_removed{i}.name,'.bin']));
end